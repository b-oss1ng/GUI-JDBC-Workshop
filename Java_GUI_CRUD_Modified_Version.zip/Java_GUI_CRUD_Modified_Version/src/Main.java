//import pages.LoginPage;
import pages.ModifiedVersion;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ModifiedVersion::new);
    }
}

/*
    Already in the database:
    admin | 1234
    ariel | 1234
*/